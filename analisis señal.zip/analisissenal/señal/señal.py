
"""
Created on Fri Jul 26 12:33:48 2024
@author: Estudiante
"""
import wfdb
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm

# Cargar la señal desde el archivo cu02
record = wfdb.rdrecord('cu02')

# Acceder a la señal (si tiene múltiples canales, elegir uno de ellos)
valores = record.p_signal[:, 0]  # Usar el primer canal de la señal

# Visualizar el número de señales
print(f"Número de señales: {record.n_sig}")

# Visualizar longitud de la señal
print(f"Longitud de la señal: {record.sig_len}")

# Graficar los valores de la señal
plt.plot(valores)
plt.title("Señal")
plt.xlabel("Tiempo (s)")  # Añadir unidades
plt.ylabel("Amplitud (mV)")  # Añadir unidades
plt.show()

# Eliminar los valores NaN de la señal
valores_limpios = valores[~np.isnan(valores)]

# Calcular los estadísticos desde cero
media = np.sum(valores_limpios) / len(valores_limpios)
suma_cuadrados = np.sum((valores_limpios - media) ** 2)
desviacion_estandar = np.sqrt(suma_cuadrados / len(valores_limpios))
coeficiente_variacion = (desviacion_estandar / media) * 100

print(f"Media calculada desde cero: {media}")
print(f"Desviación estándar calculada desde cero: {desviacion_estandar}")
print(f"Coeficiente de variación calculado desde cero: {coeficiente_variacion}%")

# Calcular los estadísticos usando funciones predefinidas
media_predef = np.mean(valores_limpios)
desviacion_estandar_predef = np.std(valores_limpios)
coeficiente_variacion_predef = (desviacion_estandar_predef / media_predef) * 100

print(f"Media calculada con funciones predefinidas: {media_predef}")
print(f"Desviación estándar calculada con funciones predefinidas: {desviacion_estandar_predef}")
print(f"Coeficiente de variación calculado con funciones predefinidas: {coeficiente_variacion_predef}%")

#---------------------------------------------------------------------------------------------------------------------

plt.figure(figsize=(12, 6))
plt.hist(valores_limpios, bins=50, alpha=0.75, edgecolor='black', density=True)
# Ajustar una distribución normal a los datos
xmin, xmax = plt.xlim()
x = np.linspace(xmin, xmax, 100)
p = norm.pdf(x, media_predef, desviacion_estandar_predef)
# Graficar la función de densidad de probabilidad
plt.plot(x, p, 'k', linewidth=2, label='Usando función python')
plt.title("Histograma de la señal y función de densidad de probabilidad")
plt.xlabel("Amplitud (mV)")  # Añadir unidades
plt.ylabel("Frecuencia (Hz)")  # Frecuencia es una cantidad adimensional
plt.legend()
plt.show()

plt.figure(figsize=(12, 6))
# Calcular los intervalos (bins) manualmente
num_bins = 50
min_val = min(valores_limpios)
max_val = max(valores_limpios)
bins = np.linspace(min_val, max_val, num_bins)
hist, bin_edges = np.histogram(valores_limpios, bins=bins, density=True)

# Graficar el histograma con barras
plt.bar(bin_edges[:-1], hist, width=np.diff(bin_edges), alpha=0.75, edgecolor='black', align='edge')
# Ajustar una distribución normal a los datos
xmin, xmax = plt.xlim()
x = np.linspace(xmin, xmax, 100)
p = norm.pdf(x, media_predef, desviacion_estandar_predef)
plt.plot(x, p, 'k', linewidth=2, label='Distribución Normal')

plt.title("Histograma de la señal y función de densidad de probabilidad")
plt.xlabel("Amplitud (mV)")  # Añadir unidades
plt.ylabel("Frecuencia (Hz)")  # Frecuencia es una cantidad adimensional
plt.legend()
plt.show()

#---------------------------------------------------------------------------------------------------------------------

# Contaminar la señal con ruido gaussiano
ruido = np.random.normal(0, 1, len(valores_limpios))/25
senal_contaminada = (valores_limpios) + (ruido)

# Graficar la señal contaminada
plt.figure(figsize=(12, 6))
plt.plot(senal_contaminada, label='.')
plt.title("Señal Contaminada con Ruido Gaussiano")
plt.xlabel("Tiempo (s)")  # Añadir unidades
plt.ylabel("Amplitud (mV)")  # Añadir unidades
plt.legend()
plt.show()

# Calcular la relación señal-ruido (SNR)
potencia_senal = np.mean(valores_limpios ** 2)
potencia_ruido = np.mean(ruido ** 2)
snr = 10 * np.log10(potencia_senal / potencia_ruido)

print(f"Relación Señal-Ruido Gaussiano (SNR): {snr} dB")

plt.figure(figsize=(12, 6))
plt.plot(ruido, label='.')
plt.title("Ruido Gaussiano")
plt.xlabel("Tiempo (s)")  # Añadir unidades
plt.ylabel("Amplitud (mV)")  # Añadir unidades
plt.legend()
plt.show()

# Contaminar la señal con ruido gaussiano #2
ruido = np.random.normal(0, 1, len(valores_limpios))*12
senal_contaminada = (valores_limpios) + (ruido)

# Graficar la señal contaminada
plt.figure(figsize=(12, 6))
plt.plot(senal_contaminada, label='.')
plt.title("Señal Contaminada con Ruido Gaussiano 2")
plt.xlabel("Tiempo (s)")  # Añadir unidades
plt.ylabel("Amplitud (mV)")  # Añadir unidades
plt.legend()
plt.show()

# Calcular la relación señal-ruido (SNR)
potencia_senal = np.mean(valores_limpios ** 2)
potencia_ruido = np.mean(ruido ** 2)
snr = 10 * np.log10(potencia_senal / potencia_ruido)

print(f"Relación Señal-Ruido Gaussiano 2 (SNR): {snr} dB")

plt.figure(figsize=(12, 6))
plt.plot(ruido, label='.')
plt.title("Ruido Gaussiano")
plt.xlabel("Tiempo (s)")  # Añadir unidades
plt.ylabel("Amplitud (mV)")  # Añadir unidades
plt.legend()
plt.show()

#---------------------------------------------------------------------------------------------------------------------

# Contaminar la señal con ruido impulsivo
probabilidad_impulso = 0.01  # Probabilidad de ocurrencia de un impulso
amplitud_impulso = 3 * desviacion_estandar_predef  # Amplitud del impulso
num_impulsos = int(probabilidad_impulso * len(valores_limpios))
indices_impulso = np.random.choice(len(valores_limpios), num_impulsos, replace=False)
ruido_impulsivo = np.zeros_like(valores_limpios)
ruido_impulsivo[indices_impulso] = np.random.choice([-1, 1], num_impulsos) * amplitud_impulso
senal_contaminada_impulsiva = valores_limpios + ruido_impulsivo

# Graficar la señal contaminada con ruido impulsivo
plt.figure(figsize=(12, 6))
plt.plot(senal_contaminada_impulsiva, label='.')
plt.title("Señal Contaminada con Ruido Impulsivo")
plt.xlabel("Tiempo (s)")  # Añadir unidades
plt.ylabel("Amplitud (mV)")  # Añadir unidades
plt.legend()
plt.show()

plt.figure(figsize=(12, 6))
plt.plot(ruido_impulsivo, label='.')
plt.title("Ruido Impulsivo")
plt.xlabel("Tiempo (s)")  # Añadir unidades
plt.ylabel("Amplitud (mV)")  # Añadir unidades
plt.legend()
plt.show()
# Calcular la relación señal-ruido (SNR) para ruido impulsivo
potencia_ruido_impulsivo = np.mean(ruido_impulsivo ** 2)
snr_impulsivo = 10 * np.log10(potencia_senal / potencia_ruido_impulsivo)

print(f"Relación Señal-Ruido con Ruido Impulsivo (SNR): {snr_impulsivo} dB")

# Contaminar la señal con ruido impulsivo
probabilidad_impulso = 0.01  # Probabilidad de ocurrencia de un impulso
amplitud_impulso = 40 * desviacion_estandar_predef  # Amplitud del impulso
num_impulsos = int(probabilidad_impulso * len(valores_limpios))
indices_impulso = np.random.choice(len(valores_limpios), num_impulsos, replace=False)
ruido_impulsivo = np.zeros_like(valores_limpios)
ruido_impulsivo[indices_impulso] = np.random.choice([-1, 1], num_impulsos) * amplitud_impulso
senal_contaminada_impulsiva = valores_limpios + ruido_impulsivo

# Graficar la señal contaminada con ruido impulsivo 2
plt.figure(figsize=(12, 6))
plt.plot(senal_contaminada_impulsiva, label='.')
plt.title("Señal Contaminada con Ruido Impulsivo 2")
plt.xlabel("Tiempo (s)")  # Añadir unidades
plt.ylabel("Amplitud (mV)")  # Añadir unidades
plt.legend()
plt.show()

plt.figure(figsize=(12, 6))
plt.plot(ruido_impulsivo, label='.')
plt.title("Ruido Impulsivo")
plt.xlabel("Tiempo (s)")  # Añadir unidades
plt.ylabel("Amplitud (mV)")  # Añadir unidades
plt.legend()
plt.show()
# Calcular la relación señal-ruido (SNR) para ruido impulsivo
potencia_ruido_impulsivo = np.mean(ruido_impulsivo ** 2)
snr_impulsivo = 10 * np.log10(potencia_senal / potencia_ruido_impulsivo)

print(f"Relación Señal-Ruido con Ruido Impulsivo 2 (SNR): {snr_impulsivo} dB")

#---------------------------------------------------------------------------------------------------------------------

# Contaminar la señal con ruido tipo artefacto
probabilidad_artefacto = 0.02  # Probabilidad de ocurrencia de un artefacto
amplitud_artefacto = 2 * desviacion_estandar_predef  # Amplitud del artefacto
num_artefactos = int(probabilidad_artefacto * len(valores_limpios))
indices_artefacto = np.random.choice(len(valores_limpios), num_artefactos, replace=False)
ruido_artefacto = np.zeros_like(valores_limpios)
ruido_artefacto[indices_artefacto] = np.random.choice([-1, 1], num_artefactos) * amplitud_artefacto
senal_contaminada_artefacto = valores_limpios + ruido_artefacto

# Graficar la señal contaminada con ruido tipo artefacto
plt.figure(figsize=(12, 6))
plt.plot(senal_contaminada_artefacto, label= '.')
plt.title("Señal Contaminada con Ruido Tipo Artefacto")
plt.xlabel("Tiempo (s)")  # Añadir unidades
plt.ylabel("Amplitud (mV)")  # Añadir unidades
plt.legend()
plt.show()

plt.figure(figsize=(12, 6))
plt.plot(ruido_artefacto, label='.')
plt.title("Ruido Artefacto")
plt.xlabel("Tiempo (s)")  # Añadir unidades
plt.ylabel("Amplitud (mV)")  # Añadir unidades
plt.legend()
plt.show()

# Calcular la relación señal-ruido (SNR) para ruido tipo artefacto
potencia_ruido_artefacto = np.mean(ruido_artefacto ** 2)
snr_artefacto = 10 * np.log10(potencia_senal / potencia_ruido_artefacto)

print(f"Relación Señal-Ruido con Ruido Tipo Artefacto (SNR): {snr_artefacto} dB")

probabilidad_artefacto = 0.02  # Probabilidad de ocurrencia de un artefacto
amplitud_artefacto = 50 * desviacion_estandar_predef  # Amplitud del artefacto
num_artefactos = int(probabilidad_artefacto * len(valores_limpios))
indices_artefacto = np.random.choice(len(valores_limpios), num_artefactos, replace=False)
ruido_artefacto = np.zeros_like(valores_limpios)
ruido_artefacto[indices_artefacto] = np.random.choice([-1, 1], num_artefactos) * amplitud_artefacto
senal_contaminada_artefacto = valores_limpios + ruido_artefacto

# Graficar la señal contaminada con ruido tipo artefacto 2
plt.figure(figsize=(12, 6))
plt.plot(senal_contaminada_artefacto, label= '.')
plt.title("Señal Contaminada con Ruido Tipo Artefacto 2")
plt.xlabel("Tiempo (s)")  # Añadir unidades
plt.ylabel("Amplitud (mV)")  # Añadir unidades
plt.legend()
plt.show()

plt.figure(figsize=(12, 6))
plt.plot(ruido_artefacto, label='.')
plt.title("Ruido Artefacto")
plt.xlabel("Tiempo (s)")  # Añadir unidades
plt.ylabel("Amplitud (mV)")  # Añadir unidades
plt.legend()
plt.show()

# Calcular la relación señal-ruido (SNR) para ruido tipo artefacto
potencia_ruido_artefacto = np.mean(ruido_artefacto ** 2)
snr_artefacto = 10 * np.log10(potencia_senal / potencia_ruido_artefacto)

print(f"Relación Señal-Ruido con Ruido Tipo Artefacto 2 (SNR): {snr_artefacto} dB")
